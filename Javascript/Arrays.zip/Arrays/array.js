// 1. Arraylarni e'lon qilish. 
// var empty = []  // Bo'sh massiv.
// var raqamlar = [2,3,4,6,8] // Raqamli array
// var misc = [1.1, true, "a"] // 3 ta har hil element
// var el = 1024;
// var table = [el, el+1, el+2] // O'zgaruvchilar bilan
// var arrObj = [
//     [1, {x:1, y:2}],
//     [2, {x:3, y:4}]
// ]
// var arr = new Array();
// var arr1 = new Array(10)
// var arr2 = new Array(5, 4 , 3, "test")


// // 2. Arrayga murojat qilish va o'zgartirish.
// console.log(raqamlar);
// console.log(raqamlar[1]);
// console.log(raqamlar.length);
// raqamlar[2] = "456"
// console.log(raqamlar);
// raqamlar[raqamlar.length] = 'New element'
// console.log(raqamlar);

// 3. Arrayni oxiriga ma'lumot qo'shish.
// var arr = []
// console.log(arr);

// arr.push('Bir')
// console.log(arr);
// arr.push('Ikki')
// console.log(arr);

// 4. Boshiga ma'lumot qo'shish
var arr2 = [1,2,3,4,5,6,7]
console.log(arr2);
arr2.unshift('Bir')
console.log(arr2);

// 5. Boshidan bitta element o'chiradi.
arr2.shift()
console.log(arr2);

// 6. Oxiridan bitta element o'chiradi.

arr2.pop()
console.log(arr2);

delete arr2(2)
// console.log(arr2);

const data = [
    {name: "NOmi", info: "infodwdw"},
    {name: "NOmi", info: "infodwdw"},
    {name: "NOmi", info: "infodwdw"},
    {name: "NOmi", info: "infodwdw"},
]
