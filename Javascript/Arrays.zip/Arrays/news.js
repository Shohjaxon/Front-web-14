const data = [
  { name: "Nomi 1", info: "info 1" },
  { name: "Nomi 2", info: "info 2" },
  { name: "Nomi 3", info: "info 3" },
  { name: "Nomi 4", info: "info 4" },
  { name: "Nomi 4", info: "info 4" },
  { name: "Nomi 4", info: "info 4" },
  { name: "Nomi 4", info: "info 4" },
  { name: "Nomi 4", info: "info 4" },
  { name: "Nomi 4", info: "info 4" },
];
var xabar = { name: "Nomi 1", info: "info 1" }
show(data)
function show(data) {
  let news = "";
  for (let xabar of data) {
    news += `
        <div class="card">
            <h3>${xabar.name}</h3>
            <p>${xabar.info}</p>
        </div>
        `;
  }
  document.getElementById("news").innerHTML = news
}
